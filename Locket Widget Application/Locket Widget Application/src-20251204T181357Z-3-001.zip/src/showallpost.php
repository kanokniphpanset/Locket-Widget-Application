<?php
require_once('db.php'); // เรียกไฟล์ที่เชื่อมต่อฐานข้อมูล

// ดึงข้อมูลจากวิว SHOWALLPOST
try {
    // Fetch data from SHOWALLPOST view
    $stmt = $pdo->prepare("SELECT * FROM SHOWALLPOST ORDER BY USER_ID");
    $stmt->execute();
    
    // Fetch all records as an associative array
    $SHOWALLPOST = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // ในกรณีเกิดข้อผิดพลาด ให้เก็บ log และตั้งค่าเป็น array ว่าง
    error_log("Database query error: " . $e->getMessage());
    $SHOWALLPOST = []; // ให้แน่ใจว่าตัวแปรนี้เป็น array เสมอ
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show All Posts</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        table {
            width: 50%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table, th, td {
            border: 1px solid black;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }

        .topnav {
            background-color: #333;
            overflow: hidden;
        }

        /* Style the links inside the navigation bar */
        .topnav a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        /* Change the color of links on hover */
        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Add a color to the active/current link */
        .topnav a.active {
            background-color: #FFBF00;
            color: white;
        }

        /* เพิ่มระยะห่างระหว่าง navigation bar กับ title */
        h2 {
            margin-top: 50px; /* เพิ่มระยะห่าง */
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<div class="topnav">
    <a href="index.php">Home</a>
    <a href="userphotocount.php">User Photo Count</a>
    <a href="reply_post.php">Reply Post</a>
    <a href="user_friend_member.php">User Friend Member</a>
    <a href="user_album_owner.php">User Album Owner</a>
    <a class="active" href="showallpost.php">Show All Posts</a>
</div>

<div class="container">
    <h2>Show All Posts</h2>

    <table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>USER_ID</th>
            <th>PHOTOPATH</th>
            <th>CAPTION</th>
            <th>UPLOAD_DATE</th>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($SHOWALLPOST)): ?>
            <tr>
                <td colspan="4">No data available</td>
            </tr>
        <?php else: ?>
            <?php foreach ($SHOWALLPOST as $post): ?>
            <tr>
                <td><?php echo htmlspecialchars($post['USER_ID'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($post['PHOTOPATH'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($post['CAPTION'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($post['UPLOAD_DATE'] ?? 'N/A'); ?></td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>

</body>
</html>
