<?php
session_start();

// Database connection parameters
$host = "10.199.8.14";  // Hostname
$port = "1521";         // Oracle port
$sid  = "ORCLCDB";      // Oracle service ID
$username = "CY_663380093_0";  // Oracle DB username
$password = "p123";     // Oracle DB password

// Create the DSN (Data Source Name) for Oracle
$dsn = "oci:dbname=//$host:$port/$sid;charset=UTF8";

try {
    // Create a new PDO instance for Oracle
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    
} catch (PDOException $e) {
echo "". $e->getMessage() ."";
    exit(); // หยุดการทำงานของสคริปต์หากเชื่อมต่อไม่ได้
}
?>
