<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locket Widget</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Add a black background color to the top navigation */
        .topnav {
            background-color: #333;
            overflow: hidden;
        }

        /* Style the links inside the navigation bar */
        .topnav a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        /* Change the color of links on hover */
        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Add a color to the active/current link */
        .topnav a.active {
            background-color: #FFBF00;
            color: white;
        }

        /* Body styles */
        body {
            background-color: #f8f9fa; /* Light gray background */
            padding: 20px;
        }

        /* Container styles */
        .container {
            margin-top: 20px;
            background-color: #ffffff; /* White background for content */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            padding: 20px;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<div class="topnav">
    <a class="active" href="index.php">Home</a>
    <a href="userphotocount.php">User Photo Count</a>
    <a href="reply_post.php">Reply Post</a>
    <a href="user_friend_member.php">User Friend Member</a>
    <a href="user_album_owner.php">User Album Owner</a>
    <a href="showallpost.php">Show All Posts</a>
</div>

<div class="container mt-4">
    <h1>Welcome to Locket Widget!</h1>
    <div class="row">
        <!-- Your existing product display code would go here -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">

                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body">

                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
