<?php
require_once('db.php'); // Include the database connection file

// Fetch data from the USERPHOTOCOUNT view
try {
    // Prepare the SQL statement to fetch data
    $stmt = $pdo->prepare("SELECT * FROM USERPHOTOCOUNT ORDER BY USER_ID");
    $stmt->execute();
    
    // Fetch all data as an associative array
    $userPhotoCount = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Log any database query errors
    error_log("Database query error: " . $e->getMessage());
    $userPhotoCount = []; // Ensure this variable is always an array
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Photo Count</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .topnav {
            background-color: #333;
            overflow: hidden;
        }

        /* Style the links inside the navigation bar */
        .topnav a {
            float: left;
            color: #f2f2f2;
            text-align: center;
            padding: 14px 16px;
            text-decoration: none;
            font-size: 17px;
        }

        /* Change the color of links on hover */
        .topnav a:hover {
            background-color: #ddd;
            color: black;
        }

        /* Add a color to the active/current link */
        .topnav a.active {
            background-color: #FFBF00;
            color: white;
        }

        /* Body styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }

        h2 {
            margin-top: 20px;
            color: #343a40; /* Dark grey for headings */
        }

        /* Card Styles */
        .card {
            margin: 10px 0;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Light shadow */
            border-radius: 10px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .card:hover {
            transform: translateY(-5px); /* Slight hover effect */
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Stronger shadow on hover */
        }

        .bg-card-1 {
            background-color: #ffe5e7; /* Soft pink */
        }

        .bg-card-2 {
            background-color: #e0f7fa; /* Soft blue */
        }

        .bg-card-3 {
            background-color: #e8f5e9; /* Soft green */
        }

        /* Responsive layout for the grid */
        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); /* Responsive columns */
            gap: 20px;
        }
    </style>
</head>
<body>

<!-- Navigation Bar -->
<div class="topnav">
    <a href="index.php">Home</a>
    <a class="active" href="userphotocount.php">User Photo Count</a>
    <a href="reply_post.php">Reply Post</a>
    <a href="user_friend_member.php">User Friend Member</a>
    <a href="user_album_owner.php">User Album Owner</a>
    <a href="showallpost.php">Show All Posts</a>
</div>

<div class="container">
    <h2>User Photo Count</h2>

    <!-- Data Cards -->
    <div class="card-container">
        <?php if (empty($userPhotoCount)): ?>
            <div class="alert alert-warning text-center">No data available</div>
        <?php else: ?>
            <?php foreach ($userPhotoCount as $index => $user): ?>
                <div class="card bg-card-<?php echo ($index % 3) + 1; ?>">
                    <div class="card-body">
                        <h5 class="card-title">User ID: <?php echo htmlspecialchars($user['USER_ID'] ?? 'N/A'); ?></h5>
                        <p class="card-text">Total Posts: <?php echo htmlspecialchars($user['TOTAL_POST'] ?? 'N/A'); ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
