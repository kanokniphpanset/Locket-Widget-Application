<?php
require_once('db.php'); // เรียกไฟล์ที่เชื่อมต่อฐานข้อมูล

// ดึงข้อมูลจากตาราง REPLY_POST
try {
    // Fetch data from REPLY_POST view
    $stmt = $pdo->prepare("SELECT * FROM REPLY_POST ORDER BY user_id");
    $stmt->execute();
    
    // Fetch all records as an associative array
    $REPLY_POST = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // ในกรณีเกิดข้อผิดพลาด ให้เก็บ log และตั้งค่าเป็น array ว่าง
    error_log("Database query error: " . $e->getMessage());
    $REPLY_POST = []; // ให้แน่ใจว่าตัวแปรนี้เป็น array เสมอ
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REPLY POST LIST</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 20px;
    }
    table {
        width: 50%;
        margin: 20px 0;
    }
    th {
        background-color: #f2f2f2;
    }
    .topnav {
        background-color: #333;
        overflow: hidden;
    }

    /* Style the links inside the navigation bar */
    .topnav a {
        float: left;
        color: #f2f2f2;
        text-align: center;
        padding: 14px 16px;
        text-decoration: none;
        font-size: 17px;
    }

    /* Change the color of links on hover */
    .topnav a:hover {
        background-color: #ddd;
        color: black;
    }

    /* Add a color to the active/current link */
    .topnav a.active {
        background-color: #FFBF00;
        color: white;
    }

    /* เพิ่มระยะห่างระหว่าง navigation bar กับ title */
    h2 {
        margin-top: 35px; /* เพิ่มระยะห่าง */
    }
</style>

</head>
<body>

<!-- Navigation Bar -->
<div class="topnav">
    <a href="index.php">Home</a>
    <a href="userphotocount.php">User Photo Count</a>
    <a class="active" href="reply_post.php">Reply Post</a>
    <a href="user_friend_member.php">User Friend Member</a>
    <a href="user_album_owner.php">User Album Owner</a>
    <a href="showallpost.php">Show All Posts</a>
</div>

<div class="container">
<h2>Reply Post</h2>

    <table class="table table-bordered table-striped">
    <thead class="table-dark">
        <tr>
            <th>USERNAME</th>
            <th>USER_ID</th>
            <th>MESSAGE</th>
            <th>POST_ID</th>
            <th>RECIVED</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($REPLY_POST)): ?>
            <tr>
                <td colspan="5">No data available</td>
            </tr>
        <?php else: ?>
            <?php foreach ($REPLY_POST as $reply): ?>
            <tr>
                <td><?php echo htmlspecialchars($reply['USERNAME'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($reply['USER_ID'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($reply['MESSAGE'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($reply['POST_ID'] ?? 'N/A'); ?></td>
                <td><?php echo htmlspecialchars($reply['RECIVED'] ?? 'N/A'); ?></td>
            </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
    </table>

</div>

</body>
</html>
